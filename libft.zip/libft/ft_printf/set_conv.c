/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   set_conv.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ashongwe <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/09 07:50:52 by ashongwe          #+#    #+#             */
/*   Updated: 2019/08/09 09:18:35 by ashongwe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

char		*init_d(va_list ap, t_printf *specs)
{
	char	*s;

	if (specs->converter == 'D')
	{
		specs->isl = 1;
		specs->ish = 0;
		specs->ishh = 0;
	}
	s = convert_d(ap, specs);
	return (s);
}

char		*init_s(va_list ap, t_printf *specs)
{
	char	*s;

	if (!ft_strchr(SPECIFIERS, specs->converter))
	{
		if (specs->width >= 0)
			specs->precision = -1;
		s = ft_strdup(&(specs->converter));
	}
	else if (specs->converter == 'S' || specs->isl)
		s = wstring(va_arg(ap, wchar_t*));
	else
		s = ft_strdup(va_arg(ap, char*));
	if (!s)
		s = ft_strdup("(null)");
	s = convert_s(s, specs);
	return (s);
}

char		*handle_percent(t_printf *specs)
{
	specs->precision = -1;
	specs->isplus = 0;
	return (padding(ft_strdup("%\0"), specs));
}

int			empty_string(t_printf *specs, int count)
{
	char	*s;

	specs->precision = 0;
	specs->width--;
	s = padding(ft_strdup(""), specs);
	if (specs->isminus)
	{
		ft_putchar('\0');
		count += ft_putstr(s);
		return (count + 1);
	}
	count += ft_putstr(s);
	ft_putchar('\0');
	return (count + 1);
}
