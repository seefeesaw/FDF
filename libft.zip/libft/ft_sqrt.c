/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sqrt.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ashongwe <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/08 17:46:48 by ashongwe          #+#    #+#             */
/*   Updated: 2019/08/08 17:46:51 by ashongwe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	ft_sqrt(const int nb)
{
	int result;

	if (!(nb % 2 >= 0))
		return (0);
	result = 1;
	while (result <= nb / result)
	{
		if (result == nb / result && nb % result == 0)
			return (result);
		result++;
	}
	return (0);
}
