/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.h                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ashongwe <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/09 10:59:34 by ashongwe          #+#    #+#             */
/*   Updated: 2019/09/15 11:31:44 by ashongwe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef GET_NEXT_LINE_H
# define GET_NEXT_LINE_H

# include "../libft.h"
# include <sys/types.h>
# include <sys/uio.h>

# define BUFF_SIZE	32
# define MAX_FD		4865

int		get_next_line(const int fd, char **line);

#endif
